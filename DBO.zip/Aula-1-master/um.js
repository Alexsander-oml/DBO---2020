console.log('arquivo um');
var x = 'alek';
