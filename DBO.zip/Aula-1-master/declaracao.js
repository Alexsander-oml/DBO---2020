
var idade; //declaração de variável
console.log(idade);
idade = 16; //atribuição de variável
console.log(idade);
//var idade = 44; //não redeclarar
idade = 44; //reatribuir
let nome = 'alek'; //declarar e atribuir
nome = 'santos';
const ano = 2003; //constante
console.log(x, nome, ano);
