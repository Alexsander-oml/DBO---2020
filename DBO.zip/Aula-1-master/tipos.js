let p = 'teste';
console.log(p); // teste
console.log(typeof(p)); //string
p = 1;
console.log(p); // 1
console.log(typeof(p)); //number
let b = true; //boolean
console.log(b); //true

let chamada = ['alek','nella']; //array
console.log(chamada); //
console.table(chamada);
console.log(typeof(chamada));

let dados = {bim1: 7.5, bim2: 8}; //objeto, hash, dict, map
console.log(dados['bim1']); //7.5 // key-value



